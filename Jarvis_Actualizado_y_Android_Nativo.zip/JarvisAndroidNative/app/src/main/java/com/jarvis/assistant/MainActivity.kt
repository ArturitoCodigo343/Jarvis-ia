package com.jarvis.assistant

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Pantalla de permisos inicial de Jarvis.
 * Los permisos se solicitan solo después de pulsar el botón correspondiente.
 * No lee mensajes ni envía SMS automáticamente.
 */
class MainActivity : android.app.Activity() {
    private lateinit var status: TextView

    private val requestNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> updateStatus("Notificaciones: ${if (granted) "permitidas" else "no permitidas"}") }

    private val requestSms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.filterValues { it }.keys
        updateStatus("Permisos SMS concedidos: ${if (granted.isEmpty()) "ninguno" else granted.joinToString()}")
    }

    private val requestCallLog = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> updateStatus("Historial de llamadas: ${if (granted) "permiso concedido" else "permiso denegado"}") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "JARVIS · Permisos de Android"
            textSize = 24f
        }
        status = TextView(this).apply {
            textSize = 14f
            text = "Los permisos son opcionales. Activa solo los que quieras utilizar."
            setPadding(0, 20, 0, 20)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(actionButton("Permitir notificaciones de Jarvis") { askNotificationPermission() })
        layout.addView(actionButton("Permitir analizar notificaciones de WhatsApp y otras apps") { openNotificationAccessSettings() })
        layout.addView(actionButton("Solicitar permisos para SMS") { askSmsPermissions() })
        layout.addView(actionButton("Solicitar permiso para historial de llamadas") { askCallLogPermission() })
        layout.addView(actionButton("Permitir alarmas exactas (recordatorios)") { openExactAlarmSettings() })
        layout.addView(actionButton("Comprobar permisos actuales") { refreshStatus() })
        val note = TextView(this).apply {
            text = "Privacidad y límites: el acceso a notificaciones puede mostrar solo el contenido que cada app expone en sus notificaciones; no permite leer automáticamente todo el historial de WhatsApp. SMS y registro de llamadas son permisos sensibles y pueden estar restringidos por Android o las políticas de Google Play. Esta pantalla no envía mensajes ni graba llamadas."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(note)
        scroll.addView(layout)
        setContentView(scroll)
        refreshStatus()
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else updateStatus("Android anterior a 13: no se requiere el permiso POST_NOTIFICATIONS.")
    }

    private fun openNotificationAccessSettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        updateStatus("En Ajustes, selecciona Jarvis y activa el acceso a notificaciones si deseas permitirlo.")
    }

    private fun askSmsPermissions() {
        requestSms.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS))
    }

    private fun askCallLogPermission() {
        requestCallLog.launch(Manifest.permission.READ_CALL_LOG)
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(AlarmManager::class.java)
            if (manager.canScheduleExactAlarms()) {
                updateStatus("Jarvis ya puede programar alarmas exactas.")
                return
            }
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
            updateStatus("Activa Permitir alarmas y recordatorios para Jarvis, si Android ofrece esa opción.")
        } else updateStatus("Esta versión de Android no requiere acceso especial para alarmas exactas.")
    }

    private fun refreshStatus() {
        val sms = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        val calls = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        updateStatus("Estado actual\nNotificaciones de Jarvis: $notifications\nLectura SMS: $sms\nHistorial de llamadas: $calls\nAlarmas exactas: $exact\nAcceso a notificaciones de otras apps: revisa el botón correspondiente en Ajustes de Android.")
    }

    private fun updateStatus(message: String) {
        status.text = message
    }
}
