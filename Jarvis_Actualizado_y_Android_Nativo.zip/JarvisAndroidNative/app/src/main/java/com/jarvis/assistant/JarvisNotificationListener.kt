package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Punto de entrada nativo para notificaciones autorizadas.
 * Por privacidad, esta plantilla NO persiste el texto ni lo manda a una IA.
 * La integración real debe aplicar exclusiones por app/contacto antes de procesar.
 */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val packageName = sbn.packageName.orEmpty()
        // Solo diagnóstico sin registrar el contenido privado del mensaje.
        Log.d("JarvisNotifications", "Notificación recibida de $packageName; tieneTítulo=${title.isNotBlank()}; tieneTexto=${text.isNotBlank()}")
        // TODO: comprobar exclusiones y consentimiento antes de procesar title/text.
    }
}
