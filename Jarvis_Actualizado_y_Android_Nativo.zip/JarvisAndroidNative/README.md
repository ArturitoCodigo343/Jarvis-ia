# Jarvis Android Native — base de integración

Este directorio es un esqueleto de código Android separado del HTML. Kotlin y AndroidManifest.xml no pueden ejecutarse dentro de `Jarvis_Acode_Ampliado.html`; hay que incorporarlos a un proyecto Android y compilarlo con Android Studio o un entorno Android compatible.

## Incluye
- Solicitud explícita de permiso para notificaciones (Android 13+).
- Acceso a notificaciones de otras apps mediante pantalla de Ajustes del sistema.
- Solicitud explícita de permisos SMS y registro de llamadas.
- Acceso especial para alarmas exactas cuando la versión de Android lo requiere.
- Servicio `NotificationListenerService` como punto de integración para notificaciones autorizadas.
- Receptor mínimo de notificaciones de recordatorio nativas.

## Limitaciones y seguridad
- No lee automáticamente el historial completo de WhatsApp; solo puede recibir las notificaciones que Android y cada app expongan.
- Esta plantilla no lee, almacena ni envía mensajes; no graba ni transcribe llamadas.
- Los permisos de SMS y registro de llamadas están sujetos a restricciones del sistema y políticas de distribución; concederlos no garantiza que Google Play permita publicar la app con esos usos.
- `ReminderAlarmReceiver` muestra una notificación si se programa una alarma, pero todavía falta implementar el programador persistente de cada evento, el almacenamiento nativo, la restauración tras reinicio y la sincronización con la agenda HTML.
- Las alarmas exactas y las notificaciones dependen de los permisos y de las políticas de batería del dispositivo.
- El acceso a notificaciones es sensible: la app final debe tener exclusiones por aplicación/contacto y evitar procesar contenido excluido.

## Compilación
Usa un entorno compatible con Gradle y Android SDK. Revisa versiones de Android Gradle Plugin/SDK según el entorno disponible. No se ha podido compilar este proyecto en este entorno, así que es código base sujeto a prueba y ajustes.
